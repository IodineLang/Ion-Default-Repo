#!/bin/bash
./cgi-bin/routerdemo.id
